package com.notkac.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

final class UpdateManager {
    private static final String RELEASE_API = "https://api.github.com/repos/mahitan3493-spec/notkac-android/releases/latest";
    private static final String PREFS = "notkac_update";
    private static final String LAST_CHECK = "last_check";
    private static final long CHECK_INTERVAL_MS = 6L * 60L * 60L * 1000L;

    private final Activity activity;
    private final DownloadManager downloadManager;
    private long updateDownloadId = -1L;
    private Uri pendingApkUri;
    private boolean registered;

    UpdateManager(Activity activity) {
        this.activity = activity;
        this.downloadManager = (DownloadManager) activity.getSystemService(Context.DOWNLOAD_SERVICE);
    }

    void register() {
        if (registered) return;
        IntentFilter filter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        if (Build.VERSION.SDK_INT >= 33) {
            activity.registerReceiver(downloadReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            activity.registerReceiver(downloadReceiver, filter);
        }
        registered = true;
    }

    void unregister() {
        if (!registered) return;
        try {
            activity.unregisterReceiver(downloadReceiver);
        } catch (Exception ignored) {
        }
        registered = false;
    }

    void checkForUpdates() {
        SharedPreferences prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long now = System.currentTimeMillis();
        if (now - prefs.getLong(LAST_CHECK, 0L) < CHECK_INTERVAL_MS) return;
        prefs.edit().putLong(LAST_CHECK, now).apply();

        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(RELEASE_API);
                connection = (HttpURLConnection) url.openConnection();
                connection.setConnectTimeout(8000);
                connection.setReadTimeout(8000);
                connection.setRequestProperty("Accept", "application/vnd.github+json");
                connection.setRequestProperty("User-Agent", "NotKac-Android-Updater");

                int code = connection.getResponseCode();
                if (code != 200) return;

                StringBuilder body = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) body.append(line);
                }

                JSONObject release = new JSONObject(body.toString());
                String tag = release.optString("tag_name", "").trim();
                String latestVersion = normalizeVersion(tag);
                String currentVersion = getCurrentVersion();
                if (latestVersion.isEmpty() || !isNewer(latestVersion, currentVersion)) return;

                String apkUrl = null;
                String apkName = null;
                JSONArray assets = release.optJSONArray("assets");
                if (assets != null) {
                    for (int i = 0; i < assets.length(); i++) {
                        JSONObject asset = assets.optJSONObject(i);
                        if (asset == null) continue;
                        String name = asset.optString("name", "");
                        String download = asset.optString("browser_download_url", "");
                        if (name.toLowerCase(Locale.ROOT).endsWith(".apk") && isTrustedDownloadUrl(download)) {
                            apkName = name;
                            apkUrl = download;
                            break;
                        }
                    }
                }
                if (apkUrl == null) return;

                String finalApkUrl = apkUrl;
                String finalApkName = apkName != null ? apkName : "NotKac-update.apk";
                activity.runOnUiThread(() -> showUpdateDialog(currentVersion, latestVersion, finalApkUrl, finalApkName));
            } catch (Exception ignored) {
                // Update checks must never block or break the app.
            } finally {
                if (connection != null) connection.disconnect();
            }
        }).start();
    }

    private void showUpdateDialog(String currentVersion, String latestVersion, String apkUrl, String apkName) {
        if (activity.isFinishing()) return;
        new AlertDialog.Builder(activity)
                .setTitle("Yeni NotKaç sürümü hazır")
                .setMessage("v" + latestVersion + " yayınlandı. Mevcut sürüm: v" + currentVersion + ".\n\nGüncelleme indirildikten sonra Android kurulum için son onayınızı isteyecek.")
                .setNegativeButton("Daha sonra", null)
                .setPositiveButton("Güncelle", (dialog, which) -> downloadUpdate(apkUrl, apkName))
                .show();
    }

    private void downloadUpdate(String apkUrl, String apkName) {
        try {
            if (!isTrustedDownloadUrl(apkUrl)) return;
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(apkUrl));
            request.setTitle("NotKaç güncellemesi");
            request.setDescription(apkName + " indiriliyor");
            request.setMimeType("application/vnd.android.package-archive");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(false);
            request.setDestinationInExternalFilesDir(activity, Environment.DIRECTORY_DOWNLOADS, apkName);
            updateDownloadId = downloadManager.enqueue(request);
            Toast.makeText(activity, "NotKaç güncellemesi indiriliyor…", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(activity, "Güncelleme indirilemedi.", Toast.LENGTH_SHORT).show();
        }
    }

    private final BroadcastReceiver downloadReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(intent.getAction())) return;
            long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L);
            if (id != updateDownloadId || id == -1L) return;
            Uri uri = downloadManager.getUriForDownloadedFile(id);
            if (uri == null) {
                Toast.makeText(activity, "Güncelleme dosyası açılamadı.", Toast.LENGTH_SHORT).show();
                return;
            }
            pendingApkUri = uri;
            requestInstallOrOpen();
        }
    };

    void onResume() {
        if (pendingApkUri != null && canInstallPackages()) {
            Uri uri = pendingApkUri;
            pendingApkUri = null;
            openInstaller(uri);
        }
    }

    private void requestInstallOrOpen() {
        if (canInstallPackages()) {
            Uri uri = pendingApkUri;
            pendingApkUri = null;
            openInstaller(uri);
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            new AlertDialog.Builder(activity)
                    .setTitle("Kurulum izni gerekli")
                    .setMessage("NotKaç güncellemesini kurabilmek için bu uygulamaya ‘Bilinmeyen uygulamaları yükle’ izni vermeniz gerekiyor. Bu izin yalnızca NotKaç APK güncellemeleri için kullanılır.")
                    .setNegativeButton("Vazgeç", (d, w) -> pendingApkUri = null)
                    .setPositiveButton("Ayarları Aç", (d, w) -> {
                        Intent settingsIntent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                Uri.parse("package:" + activity.getPackageName()));
                        activity.startActivity(settingsIntent);
                    })
                    .show();
        }
    }

    private boolean canInstallPackages() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.O
                || activity.getPackageManager().canRequestPackageInstalls();
    }

    private void openInstaller(Uri apkUri) {
        try {
            Intent install = new Intent(Intent.ACTION_VIEW);
            install.setDataAndType(apkUri, "application/vnd.android.package-archive");
            install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            install.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(install);
        } catch (Exception e) {
            Toast.makeText(activity, "Android kurulum ekranı açılamadı.", Toast.LENGTH_SHORT).show();
        }
    }

    private String getCurrentVersion() {
        try {
            PackageInfo info = activity.getPackageManager().getPackageInfo(activity.getPackageName(), 0);
            return info.versionName != null ? normalizeVersion(info.versionName) : "0.0.0";
        } catch (Exception e) {
            return "0.0.0";
        }
    }

    private String normalizeVersion(String value) {
        if (value == null) return "";
        String v = value.trim().toLowerCase(Locale.ROOT);
        if (v.startsWith("v")) v = v.substring(1);
        int dash = v.indexOf('-');
        if (dash >= 0) v = v.substring(0, dash);
        return v;
    }

    private boolean isNewer(String latest, String current) {
        int[] a = parseVersion(latest);
        int[] b = parseVersion(current);
        for (int i = 0; i < Math.max(a.length, b.length); i++) {
            int av = i < a.length ? a[i] : 0;
            int bv = i < b.length ? b[i] : 0;
            if (av > bv) return true;
            if (av < bv) return false;
        }
        return false;
    }

    private int[] parseVersion(String version) {
        String[] parts = version.split("\\.");
        int[] out = new int[parts.length];
        for (int i = 0; i < parts.length; i++) {
            try {
                out[i] = Integer.parseInt(parts[i].replaceAll("[^0-9]", ""));
            } catch (Exception e) {
                out[i] = 0;
            }
        }
        return out;
    }

    private boolean isTrustedDownloadUrl(String value) {
        try {
            Uri uri = Uri.parse(value);
            if (!"https".equalsIgnoreCase(uri.getScheme())) return false;
            String host = uri.getHost();
            if (host == null) return false;
            host = host.toLowerCase(Locale.ROOT);
            return host.equals("github.com") || host.endsWith(".github.com");
        } catch (Exception e) {
            return false;
        }
    }
}

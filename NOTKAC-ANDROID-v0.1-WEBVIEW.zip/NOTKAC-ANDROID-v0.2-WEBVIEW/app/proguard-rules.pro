# NotKaç v0.1 - no custom ProGuard rules yet.

# NotKaç Android v0.1 — WebView Test Uygulaması

Bu proje NotKaç'ın ilk Android test kabuğudur. `https://notkac.com` uygulama içinde açılır ve tarayıcı çubuğu gösterilmez.

## Hazır özellikler

- Uygulama adı: **NotKaç**
- Paket adı: `com.notkac.app`
- Açılış URL'si: `https://notkac.com/`
- Beyaz durum/navigasyon çubuğu
- NotKaç splash ekranı ve uygulama ikonu
- JavaScript, local storage ve cookie/oturum desteği
- PDF / dosya seçme
- Galeriden belge/fotoğraf seçme
- Kamera uygulamasından fotoğraf çekip forma yükleme
- Telefon, e-posta, SMS ve WhatsApp bağlantılarını ilgili uygulamada açma
- HTTPS zorunluluğu; cleartext HTTP kapalı
- Güvenli tarama etkin
- PDF/dosya indirme desteği
- Android geri tuşunda WebView geçmişinde geri gitme
- İnternet yok ekranı + Tekrar Dene
- `notkac.com` linkleri için uygulama deep-link altyapısı

## Android Studio ile açma

1. Android Studio'yu kurun.
2. **Open** deyip bu klasörü seçin.
3. Gradle Sync tamamlandıktan sonra bir Android telefon bağlayın.
4. Telefonunuzda Geliştirici Seçenekleri > USB hata ayıklamayı açın.
5. Android Studio'da **Run** düğmesine basın.

## Test edilmesi gereken ana akışlar

1. Ana sayfa ve menü
2. Giriş / Üye Ol
3. NotKaçSkor
4. Finansal İnceleme
5. Findeks ve TBB PDF yükleme
6. Kamera / galeri seçimi
7. iyzico ödeme yönlendirmesi ve 3D Secure dönüşü
8. OTP / Netgsm akışı
9. Rapor görüntüleme ve PDF indirme
10. WhatsApp / telefon / e-posta linkleri
11. Oturum kapatıp uygulamayı yeniden açınca doğru davranış
12. İnternet kapalıyken offline ekranı

## Play Store öncesi

Bu v0.1 **test sürümüdür**. Play Store'a göndermeden önce:

- imzalı AAB release build,
- uygulama gizlilik / veri güvenliği beyanları,
- Play Console şirket hesabı,
- uygulama ekran görüntüleri ve mağaza açıklaması,
- Google Play politika kontrolü,
- ödeme ve WebView akışının gerçek cihaz testleri

tamamlanmalıdır.

## Güvenlik notu

Uygulama NotKaç web sitesini HTTPS üzerinden açar. `usesCleartextTraffic=false` ile düz HTTP kapatılmıştır. Kart verilerinin NotKaç tarafından alınmaması ve iyzico ortamında işlenmesi mevcut web akışına bağlıdır; mağaza öncesi gerçek cihazda ayrıca doğrulanmalıdır.
